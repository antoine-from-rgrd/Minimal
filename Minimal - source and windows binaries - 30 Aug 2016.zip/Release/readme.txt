NPP "readme.txt" file follows.
=============================================

NPPAngband v.0.5.3

Along with the resources below, the NPPAngband home page and forums are located at:

http://forum.nppangband.org/

NPPAngband is a variant of Angband.  The Angband readme is included below:


Angband 3.1.0
=============

Angband is a graphical dungeon adventure game that uses textual characters
to represent the walls and floors of a dungeon and the inhabitants therein, 
in the vein of games like NetHack and Rogue.  If you need help in-game,
press '?'.

For more information, somewhere to upload your characters and screenshots,
and discuss the game, try http://angband.oook.cz/.

If you're compiling the game yourself, read http://rephial.org/wiki/Compiling.

Enjoy!

-- Andi Sidwell, maintainer
