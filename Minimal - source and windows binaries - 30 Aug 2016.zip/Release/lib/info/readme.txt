lib/info
========

This directory is empty by default. It is for 'spoiler' files, which contain
detailed information about the game. You can download these files from the 
internet, and place them in this directory to access them directly from the
in-game help system. Be warned that if you are a new player, using spoilers
may detract from your enjoyment of the game.
