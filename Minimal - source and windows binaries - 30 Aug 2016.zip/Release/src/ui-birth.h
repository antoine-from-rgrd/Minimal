#ifndef INCLUDED_UI_BIRTH_H
#define INCLUDED_UI_BIRTH_H

extern void ui_init_birthstate_handlers(void);
extern errr get_birth_command(bool wait);

#endif

